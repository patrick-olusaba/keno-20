import {useCallback, useRef} from "react";
import {KenoHistory, sendKenoData} from "../Util/wsTypes.ts";

export const Keno20WebSockets = () => {

    const gameWs = useRef<WebSocket | null>(null);
    const messageQueue = useRef<sendKenoData[]>([]);
    const historyQueue = useRef<KenoHistory[]>([]);


    const kenoConnectSocket = useCallback(() => {
        if (gameWs.current && gameWs.current.readyState !== WebSocket.CLOSED) {
            return;
        }

        gameWs.current = new WebSocket("wss://lottomotto.co.ke/ws17");
        const processMessageQueue = () => {
            while (messageQueue.current.length > 0) {
                const data = messageQueue.current.shift();
                if (data) {
                    sendData(data);
                }
            }
            while (historyQueue.current.length > 0) {
                const data = historyQueue.current.shift();
                if (data) {
                    sendHistData(data);
                }
            }
        };
        gameWs.current.onopen = () => {
            processMessageQueue();
        };

        gameWs.current.onclose = () => {
            setTimeout(() => kenoConnectSocket(), 2000);
        };


        gameWs.current.onmessage = (event: MessageEvent<string>) => {
            if (event && event.data) {
                //

            } else {
                //

            }
        };

        gameWs.current.onerror = () => {
        };

        gameWs.current.onclose = () => {
        };
    }, []);


    const sendData = (data: sendKenoData) => {
        const message = JSON.stringify(data);
        if (gameWs.current) {
            //
        }
        if (gameWs.current && gameWs.current.readyState === WebSocket.OPEN) {
            gameWs.current.send(message);
        } else {
            messageQueue.current.push(data);
        }
    };

    const sendHistData = (data: KenoHistory) => {
        const message = JSON.stringify(data);
        if (gameWs.current?.readyState === WebSocket.OPEN) {
            gameWs.current.send(message);
        } else {
            historyQueue.current.push(data);
        }
    };

    const getKenoSocketData = () => gameWs.current;
    const getKenoHistorySocketData = () => gameWs.current;

    return {
        getKenoHistorySocketData,
        kenoConnectSocket,
        sendData,
        getKenoSocketData,
        sendHistData
    };
};
