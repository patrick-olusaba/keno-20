import React, { useState } from 'react';
import HowToPlay from "./HowToPlay.tsx";
import kenoLogo from '../assets/logologo.svg';
import "../styles/styles.css";

interface TopBarProps {
    balance: number | null;
    // isLoadingBalance: boolean;
    // balanceError: string | null;
    isMuted: boolean;
    onToggleMute: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
                                                  balance,
                                                  isMuted,
                                                  onToggleMute
                                              }) => {
    const [showHowToPlay, setShowHowToPlay] = useState(false);

    return (
        <div className="top-bar">
            <div className="top-left">
                <div className="settings">
                    <button onClick={() => setShowHowToPlay(true)}>❓</button>
                    <button onClick={onToggleMute}>
                        {isMuted ? '🔇' : '🔊'}
                    </button>
                </div>
            </div>

            {/* Center: Logo */}
            <div className="top-center">
                <img src={kenoLogo} alt="Keno Logo" className="keno-logo" />
            </div>

            {/* Right: Balance */}
            <div className="top-right">
                {balance ? balance.toFixed(2) : "---"}
            </div>

            {showHowToPlay && (
                <HowToPlay onClose={() => setShowHowToPlay(false)} />
            )}
        </div>


    );
};