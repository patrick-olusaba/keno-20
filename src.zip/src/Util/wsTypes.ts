export type sendKenoData = {
    msisdn: string;
    amount: number;
    selectedNumbers: number[];
};

export type KenoHistory={
    history:string,
    msisdn:string
}


export type receiveKenoData = {
    message: "You Won" | "You Lost";
    msisdn: string;
    selectedNumbers: number[];
    MatchedNumbers: number[];
    DrawNumbers: number[];
    winnings: string;
    Balance: number;
    payoutData:Record<number, number[]>
};
export type RawHistoryItem = {
    MatchedNumbers: string;
    WinAmount: string;
    Multiplier: string;
    OutCome: string;
    Prediction: string;
    createdAt: string;
    msisdn: string;
};

export type NormalizedHistory = {
    MatchedNumbers: string;
    multiplier: number;
    win: number;
};



export type RawHistoryResponse = {
    data: RawHistoryItem[];
};


export interface BalanceRequest {
    type: "getBalance";
    msisdn: string;
}

export interface BalanceResponse {
    type: "balance";
    balance: number;
    error?: string;
}