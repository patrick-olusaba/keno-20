import React from "react";
import "../styles/styles.css";
import CoinsEffect from "./CoinsEffect.tsx";

interface KenoPopupProps {
    showPopup: boolean;
    winningNumbers: number[];
    payout: number;
}

const KenoPopup: React.FC<KenoPopupProps> = ({ showPopup, winningNumbers, payout}) => {
    if (!showPopup) return null;

    return (
        <div className="keno20-popup-overlay">
            <CoinsEffect />
            <div className="keno20-popup-content">
                <div className="keno20-popup-header">
                    <h3> Congratulations </h3>
                </div>
                <div className="keno20-popup-body">
                    <span className="keno20-highlight">Matching Numbers:</span> {winningNumbers.join(", ")}
                    <span className="keno20-highlight">Amount Won:</span> Ksh {payout.toFixed(2)}
                </div>
            </div>
        </div>
    );
};

export default KenoPopup;
