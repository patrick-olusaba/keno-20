import {Dispatch, FC, SetStateAction, useEffect, useState} from "react";
import {KenoHistory, NormalizedHistory, RawHistoryResponse} from "../Util/wsTypes.ts";
import {Keno20WebSockets} from "../Keno20WebSockets/Keno20WebSockets.ts";

interface historyProps {
    getHistory: boolean;
    OnSetGetHistory:Dispatch<SetStateAction<boolean>>
}
const Keno20History:FC<historyProps> = ({getHistory,OnSetGetHistory}) => {
    const [history, setHistory] = useState<NormalizedHistory[]>([]);

    const {sendHistData,getKenoHistorySocketData,kenoConnectSocket} = Keno20WebSockets();

    useEffect(() => {
        // connectHistorySocket();
        kenoConnectSocket();
        const socketHistory = getKenoHistorySocketData();
        if (!socketHistory) return;
        const queryParams = new URLSearchParams(window.location.search);
        const sess = queryParams.get("sess")|| "";

        if(getHistory){
            const handleSendHist=()=>{
                const kenoSendHistData: KenoHistory = {
                    msisdn: sess,

                    history: "1",

                    // msisdn: "254791847766"
                }
                sendHistData(kenoSendHistData);
            }
            handleSendHist();
        }

        if (socketHistory) {
            const messageHistHandler = (event: MessageEvent) => {
                try {
                    const parsed: RawHistoryResponse = JSON.parse(event.data);

                    if (parsed?.data && Array.isArray(parsed.data)) {
                        // normalize into your UI shape
                        const normalized = parsed.data.map(item => ({
                            MatchedNumbers: item.MatchedNumbers,                // or calculate matches if needed
                            multiplier: parseFloat(item.Multiplier),
                            win: parseFloat(item.WinAmount),
                        }));

                        setHistory(normalized);

                        console.log("history:", history)
                    }
                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                } catch (e) {
                    // console.error("Unable to parse history", e);
                }

            };

            socketHistory.addEventListener("message", messageHistHandler);
            return () => {
                socketHistory.removeEventListener("message", messageHistHandler);
            };
        }

    }, [OnSetGetHistory, getHistory, getKenoHistorySocketData, history, kenoConnectSocket, sendHistData]);

    return (
        <div className="keno20-history">
            <span className="keno20-history-title">Game History</span>
            <div className="history-container">

                    <table>
                        <thead>
                        <tr>
                            <th>Matches</th>
                            <th>Multiplier</th>
                            <th>Win</th>
                        </tr>
                        </thead>
                        <tbody>
                        {history &&(
                                <>
                                    {history.map((entry, index) => (
                                        <tr key={index}>
                                            <td>{entry.MatchedNumbers}</td>
                                            <td>{entry.multiplier.toFixed(2)}</td>
                                            <td className={entry.win > 0 ? "win-amount" : "lose-amount"}>
                                                {entry.win.toFixed(2)}
                                            </td>
                                        </tr>
                                    ))}
                                </>

                            )
                        }

                        </tbody>

                    </table>
                {}
            </div>
        </div>
    );
};

export default Keno20History;
