import React, { useEffect, useState } from "react";
import "../styles/styles.css";

const CoinsEffect: React.FC = () => {
    const [coins, setCoins] = useState<{ id: number; left: number; duration: number }[]>([]);

    useEffect(() => {
        const generateCoins = () => {
            const newCoins = Array.from({ length: 20 }, (_, index) => ({
                id: index,
                left: Math.random() * 100,
                duration: 2 + Math.random() * 2,
            }));
            setCoins(newCoins);
        };

        generateCoins();
        const interval = setInterval(generateCoins, 3000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="coins-container">
            {coins.map((coin) => (
                <div
                    key={coin.id}
                    className="coin"
                    style={{
                        left: `${coin.left}%`,
                        animationDuration: `${coin.duration}s`,
                    }}
                />
            ))}
        </div>
    );
};

export default CoinsEffect;
