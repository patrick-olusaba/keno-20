import {Dispatch, FC,  SetStateAction, useEffect, useRef} from "react";
import "../styles/styles.css";
import starImageSrc from "../assets/ballon1.png";

interface CanvasNumberGridProps {
    selectedNumbers: number[];
    drawnNumbers: number[];
    revealedNumbers: number[];
    OnRevealedNumbers: Dispatch<SetStateAction<number[]>>;
    onSelectedNumber: Dispatch<SetStateAction<number[]>>;
}

export const CanvasNumberGrid: FC<CanvasNumberGridProps> = (
    {drawnNumbers, onSelectedNumber,  selectedNumbers, revealedNumbers, OnRevealedNumbers}
) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const canvasWidth = 580;
    const canvasHeight = 480;
    const rows = 4;
    const cols = 5;
    const gap = 15;
    const borderRadius = 16;
    const shadowOffset = 10;

    const handleClick = (event: MouseEvent) => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const canvasWidth = 580;
        const canvasHeight = 480;
        const rows = 4;
        const cols = 5;
        const gap = 15;
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        const mouseX = (event.clientX - rect.left) * scaleX;
        const mouseY = (event.clientY - rect.top) * scaleY;
        const availableWidth = canvasWidth - gap * (cols - 1);
        const availableHeight = canvasHeight - gap * (rows - 1);
        const cellSize = Math.min(availableWidth / cols, availableHeight / rows);
        const col = Math.floor((mouseX - gap / 2) / (cellSize + gap));
        const row = Math.floor((mouseY - gap / 2) / (cellSize + gap));
        const number = row * cols + col + 1;

        if (number <= rows * cols) {
            onSelectedNumber((prev) => {
                if (prev.includes(number) && prev.length === 1) return prev;
                if (!prev.includes(number) && prev.length >= 7) return prev;
                return prev.includes(number) ? prev.filter((n) => n !== number) : [...prev, number];
            });
        }
    };


    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        //star effect
        const starImage = new Image();
        starImage.src = starImageSrc;

        starImage.onload = () => {
            drawGrid();
        };

        const drawGrid = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            const cellWidth = 100;
            const cellHeight = 100;
            ctx.canvas.width = canvasWidth;
            ctx.canvas.height = canvasHeight;
            ctx.fillStyle = "rgb(14,32,46)";
            ctx.fillRect(0, 0, canvasWidth, canvasHeight);

            let number = 1;

            for (let row = 0; row < rows; row++) {
                for (let col = 0; col < cols; col++) {
                    const x = col * (cellWidth + gap) + shadowOffset;
                    const y = row * (cellHeight + gap) + shadowOffset;

                    let cellColor = "#334155";
                    let shadowColor = "#1b2e42";

                    if (selectedNumbers.includes(number) && revealedNumbers.includes(number)) {
                        cellColor = "#06cc11";
                        shadowColor = "#29810c";
                    }

                    else if (revealedNumbers.includes(number)) {
                        cellColor = "#CC5500";
                        shadowColor = "#992700";
                    } else if (selectedNumbers.includes(number)) {
                        cellColor = "#720e9e";
                        shadowColor = "#560973";
                    }


                    ctx.fillStyle = cellColor;
                    ctx.shadowColor = shadowColor;
                    ctx.shadowBlur = 0;
                    ctx.shadowOffsetX = 0;
                    ctx.shadowOffsetY = 8;


                    ctx.beginPath();
                    ctx.moveTo(x + borderRadius, y);
                    ctx.lineTo(x + cellWidth - borderRadius, y);
                    ctx.quadraticCurveTo(x + cellWidth, y, x + cellWidth, y + borderRadius);
                    ctx.lineTo(x + cellWidth, y + cellHeight - borderRadius);
                    ctx.quadraticCurveTo(x + cellWidth, y + cellHeight, x + cellWidth - borderRadius, y + cellHeight);
                    ctx.lineTo(x + borderRadius, y + cellHeight);
                    ctx.quadraticCurveTo(x, y + cellHeight, x, y + cellHeight - borderRadius);
                    ctx.lineTo(x, y + borderRadius);
                    ctx.quadraticCurveTo(x, y, x + borderRadius, y);
                    ctx.closePath();
                    ctx.fill();

                    ctx.shadowColor = "transparent";
                    ctx.fillStyle = "#ffffff";
                    ctx.font = "bold 26px Arial";
                    ctx.textAlign = "center";
                    ctx.textBaseline = "middle";

                    ctx.fillText(number.toString(), x + cellWidth / 2, y + cellHeight / 2);

                    //Star effect on matched numbers
                    if (revealedNumbers.includes(number) && selectedNumbers.includes(number)) {
                        ctx.drawImage(starImage, x + 10, y + 10, 80, 80);
                    }

                    if (selectedNumbers.includes(number) && revealedNumbers.includes(number)) {
                        ctx.shadowColor = "transparent";
                        ctx.fillStyle = "#000000";
                        ctx.font = "bold 26px sans-serif";
                        ctx.textAlign = "center";
                        ctx.textBaseline = "middle";
                        ctx.fillText(number.toString(), x + cellWidth / 2, y + cellHeight / 2);
                    }
                    number++;
                }
            }
        };


        starImage.onload = () => {
            drawGrid();
        };

        drawGrid();
        // onSelectionChange(selectedNumbers);
        canvas.addEventListener("click", handleClick);
        return () => canvas.removeEventListener("click", handleClick);
    }, [canvasRef, selectedNumbers, selectedNumbers, revealedNumbers, drawnNumbers]);

    useEffect(() => {
        if (drawnNumbers.length > 0) {
            OnRevealedNumbers([]);
            drawnNumbers.forEach((num, index) => {
                setTimeout(() => {
                    OnRevealedNumbers((prev) => [...prev, num]);
                }, index * 400);
            });
        }
    }, [drawnNumbers]);


    return <canvas ref={canvasRef} className="keno20-canvas"/>;
};
