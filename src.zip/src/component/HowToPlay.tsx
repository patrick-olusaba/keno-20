import React from 'react';
import "../styles/styles.css";

interface HowToPlayModalProps {
    onClose: () => void;
}

const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
    return (
        <div className="modal">
            <div className="modal-content">
                <div className="modal-header">
                    <h2>How to Play</h2>
                    <button className="close-btn" onClick={onClose}>✖</button>
                </div>

                <ul className="how-to-list">
                    <li>🎯 <strong>Select Your Numbers</strong>: Choose 1 to 7 numbers from the grid (1 to 20).</li>
                    <li>💰 <strong>Set Your Bet</strong>: Use quick select or type your stake. Minimum bet is 1.</li>
                    <li>🎲 <strong>Place Your Bet</strong>: Click the "Bet" button to lock in your bet. The game will draw 10 numbers.</li>
                    <li>🏆 <strong>Win by Matching</strong>: Match numbers to win! Winnings use multipliers based on how many numbers you picked + matched.</li>
                    <li>📜 <strong>History</strong>: See past games, matches, multipliers, and total wins.</li>
                    <li>⚙️ <strong>Tips</strong>: More numbers = higher multipliers but lower odds. Fewer numbers = lower multipliers but higher odds.</li>
                </ul>

                <h3>Example Payouts</h3>
                <table className="payout-table">
                    <thead>
                    <tr>
                        <th>Numbers Picked</th>
                        <th>Matches</th>
                        <th>Multiplier</th>
                        <th>Win (Bet 10)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr><td>3</td><td>2</td><td>1.20x</td><td>12</td></tr>
                    <tr><td>5</td><td>4</td><td>1.20x</td><td>12</td></tr>
                    <tr><td>7</td><td>7</td><td>3.00x</td><td>30</td></tr>
                    </tbody>
                </table>

                <button className="primary-btn" onClick={onClose}>Got it</button>
            </div>
        </div>
    );
};

export default HowToPlayModal;
