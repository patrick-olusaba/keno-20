import {useCallback, useEffect, useState} from "react";
import MultiplierDisplay from "./MultiplierDisplay";
import "../styles/styles.css";
import Keno20BetControl from "./Keno20BetControls";
import {useSound} from "../Util/useSound.ts";
import {Keno20WebSockets} from "../Keno20WebSockets/Keno20WebSockets.ts";
import {receiveKenoData, sendKenoData} from "../Util/wsTypes.ts";
import Keno20History from "./Keno20History.tsx";
import {CanvasNumberGrid} from "./CanvasNumberGrid.tsx";
import Keno20Popup from "./keno20Popup.tsx";
import {TopBar} from "./TopBar.tsx";

export const MainKeno = () => {
    const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
    const [betAmount, setBetAmount] = useState<number>(20);
    const [drawnNumbers, setDrawnNumbers] = useState<number[]>([]);
    const [winningNumbers, setWinningNumbers] = useState<number[]>([]);
    const [payout, setPayout] = useState<number>(0);
    const [showPopup, setShowPopup] = useState<boolean>(false);
    const [isDrawing, setIsDrawing] = useState(false);
    const [revealedNumbers, setRevealedNumbers] = useState<number[]>([]);
    const [revealedWinningNumbers, setRevealedWinningNumbers] = useState<number[]>([]);
    const [payTable, setPayTable] = useState<Record<number, number[]>>({});
    const [resetMultiplier, setResetMultiplier] = useState(false);
    const [balance, setBalance] = useState<number | null>(null);

    const [isMuted, setIsMuted] = useState(false);
    const [getHistory, setGetHisto] = useState<boolean>(false);


    const {playSound} = useSound(isMuted, true);
    const {kenoConnectSocket, sendData, getKenoSocketData} = Keno20WebSockets();

    const handleToggleMute = () => {
        setIsMuted(prev => !prev);
        if (isMuted) {
            playSound("click")
        }
    };


    const generateRandomNumbers = (count: number, max: number): number[] => {
        const numbers = new Set<number>();
        while (numbers.size < count) {
            numbers.add(Math.floor(Math.random() * max) + 1);
        }
        return Array.from(numbers);
    };

    const HandleKenoResults = useCallback((receivedKenoData: receiveKenoData) => {

        if (receivedKenoData.Balance !== undefined) {
            setBalance(parseFloat(String(receivedKenoData.Balance)));
        }

        if (receivedKenoData) {
            setPayTable(receivedKenoData.payoutData)
            if (receivedKenoData.DrawNumbers) {
                playSound("draw");

                setTimeout(() => {
                    setDrawnNumbers(receivedKenoData.DrawNumbers);
                }, 200);

                setWinningNumbers(receivedKenoData.MatchedNumbers);
                setPayout(parseFloat(receivedKenoData.winnings));

                receivedKenoData.DrawNumbers.forEach((number, index) => {
                    setTimeout(() => {
                        setRevealedNumbers((prev) => [...prev, number]);

                        playSound("draw")

                        if (receivedKenoData.MatchedNumbers.includes(number)) {
                            setRevealedWinningNumbers((prev) => [...prev, number]);
                            playSound("match");
                        }

                        if (index === receivedKenoData.DrawNumbers.length - 1) {
                            setTimeout(() => {
                                if (receivedKenoData.message === "You Won") {
                                    playSound("win");
                                    setShowPopup(true);
                                } else {
                                    playSound("lose");
                                }
                                setIsDrawing(false);
                            }, 500);
                        }
                    }, index * 400);
                });
            }
        }

        setTimeout(() => {
        }, 5000);

    }, [playSound]);


    useEffect(() => {
        kenoConnectSocket();
        const socket = getKenoSocketData();


        if (showPopup) {
            const timer = setTimeout(() => {
                setShowPopup(false);
            }, 3000)

            return () => clearTimeout(timer);
        }

        if (socket) {
            const messageHandler = (event: MessageEvent) => {
                try {
                    const receivedData: receiveKenoData = JSON.parse(event.data);
                    HandleKenoResults(receivedData);
                } catch (e) {
                    console.error('Unable to get results', e);
                }
            };
            socket.addEventListener("message", messageHandler);
            return () => {
                socket.removeEventListener("message", messageHandler);
            };
        }


    }, [HandleKenoResults, selectedNumbers, getKenoSocketData, kenoConnectSocket, showPopup]);

    const handleClear = () => {
        if (isDrawing) return;
        setSelectedNumbers([]);
        setDrawnNumbers([]);
        setWinningNumbers([]);
        setRevealedNumbers([]);
        setRevealedWinningNumbers([]);
        setSelectedNumbers([]);
        setResetMultiplier(true);
        playSound("clear");
    };

    const autoPickNumbers = () => {
        if (isDrawing) return;
        setSelectedNumbers([]);
        setDrawnNumbers([]);
        setRevealedNumbers([]);
        setRevealedWinningNumbers([]);
        setResetMultiplier(true);

        const numbers = generateRandomNumbers(7, 20);
        setSelectedNumbers([]);

        numbers.forEach((number, index) => {
            setTimeout(() => {
                setSelectedNumbers((prev) => [...prev, number]);
                playSound("click");

                if (index === numbers.length - 1) {
                    setSelectedNumbers(numbers);
                    setResetMultiplier(false);

                }
            }, index * 500);
        });
    };

    const handleBet = () => {
        if (isDrawing) return;
        const queryParams = new URLSearchParams(window.location.search);
        const sess = queryParams.get("sess")|| "";
        const kenoSendData: sendKenoData = {
            msisdn: sess,
            // msisdn: "254791847766",
            amount: betAmount,
            selectedNumbers: selectedNumbers
        }
        sendData(kenoSendData);

        setIsDrawing(true);
        playSound("bet");

        setRevealedNumbers([]);
        setRevealedWinningNumbers([]);


        setTimeout(() => {
            setGetHisto(true);
            setTimeout(() => {
                setGetHisto(false);
            }, 50);
        }, 500);

    };


    return (
        <div className="keno20-game-container">
            <TopBar
                balance={balance}
                isMuted={isMuted}
                onToggleMute={handleToggleMute}
            />
            <div className="keno20-game-area">
                <div className="keno20-grid-canvas-container">
                    <CanvasNumberGrid
                        selectedNumbers={selectedNumbers}
                        revealedNumbers={revealedNumbers}
                        OnRevealedNumbers={setRevealedNumbers}
                        onSelectedNumber={setSelectedNumbers}
                        drawnNumbers={drawnNumbers}
                    />

                    <MultiplierDisplay
                        selectedNumbers={selectedNumbers}
                        revealedWinningNumbers={revealedWinningNumbers}
                        resetMultiplier={resetMultiplier}
                        payTable={payTable}
                    />
                </div>
                <div className='game-hist-controls'>
                    <Keno20BetControl
                        betAmount={betAmount}
                        setBetAmount={setBetAmount}
                        handleBet={handleBet}
                        selectedNumbers={selectedNumbers}
                        isDrawing={isDrawing}
                        autoPickNumbers={autoPickNumbers}
                        handleClear={handleClear}
                    />

                    <Keno20History
                        getHistory={getHistory}
                        OnSetGetHistory={setGetHisto}
                    />

                </div>

                <Keno20Popup
                    showPopup={showPopup}
                    winningNumbers={winningNumbers}
                    payout={payout}
                />
            </div>
        </div>
    );
};
